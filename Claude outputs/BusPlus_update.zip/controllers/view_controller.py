"""
Khulna University Bus Tracker (BusPlus)
View Controller (Page Renderers)
"""

from flask import Blueprint, render_template, session, redirect, url_for
from config import AppConfig
from services.tracking_service import TrackingService
from services.user_service import UserService

view_bp = Blueprint("view_bp", __name__)
tracking_service = TrackingService()
user_service = UserService()

@view_bp.route("/", methods=["GET"])
def landing_page():
    """Renders the launching page."""
    routes = tracking_service.get_all_routes()
    buses = tracking_service.get_all_buses()
    student_logged_in = (session.get("role") == "student" and bool(session.get("student_id")))
    return render_template(
        "landing.html",
        routes=routes,
        buses=buses,
        student_logged_in=student_logged_in,
        university_name=AppConfig.UNIVERSITY_NAME,
        university_short_name=AppConfig.UNIVERSITY_SHORT_NAME,
        google_maps_api_key=AppConfig.GOOGLE_MAPS_API_KEY
    )


@view_bp.route("/driver/login", methods=["GET"])
def driver_login_page():
    """Renders driver authentication page."""
    if session.get("role") == "driver" and session.get("driver_id"):
        driver = user_service.get_driver_by_id(session["driver_id"])
        if driver and driver.is_logged_in and driver.current_session_token == session.get("session_token"):
            return redirect(url_for("view_bp.driver_dashboard_page"))
    buses = tracking_service.get_all_buses()
    return render_template(
        "driver_login.html",
        buses=buses,
        routes=tracking_service.get_all_routes(),
        google_maps_api_key=AppConfig.GOOGLE_MAPS_API_KEY
    )


@view_bp.route("/driver/dashboard", methods=["GET"])
def driver_dashboard_page():
    """Driver's full-screen map. Only a signed-in driver can open it."""
    if session.get("role") != "driver" or not session.get("driver_id"):
        return redirect(url_for("view_bp.driver_login_page"))

    driver = user_service.get_driver_by_id(session["driver_id"])
    if not driver or not driver.is_logged_in or driver.current_session_token != session.get("session_token"):
        # Account was unlocked by the admin or taken over by another device
        session.pop("role", None)
        session.pop("driver_id", None)
        return redirect(url_for("view_bp.driver_login_page"))

    bus = tracking_service.get_bus_by_id(driver.assigned_bus_id)
    return render_template(
        "driver_dashboard.html",
        driver=driver.to_dict(),
        bus=bus.to_dict() if bus else {},
        routes=tracking_service.get_all_routes(),
        google_maps_api_key=AppConfig.GOOGLE_MAPS_API_KEY,
        university_location=AppConfig.UNIVERSITY_LOCATION
    )


@view_bp.route("/student/login", methods=["GET"])
def student_login_page():
    """Renders student login page where student enters name and student ID."""
    return render_template(
        "student_login.html",
        google_maps_api_key=AppConfig.GOOGLE_MAPS_API_KEY
    )


@view_bp.route("/student/dashboard", methods=["GET"])
def student_dashboard_page():
    """Renders student live Google Maps bus tracking interface."""
    routes = tracking_service.get_all_routes()
    buses = tracking_service.get_all_buses()

    student_name = session.get("student_name", "Student")
    student_id = session.get("student_id", "KU-2026-Guest")
    preferred_stop = session.get("preferred_stop", "Malabotha More")
    preferred_route_id = session.get("preferred_route_id", "KU-R01")
    alert_lead_minutes = session.get("alert_lead_minutes", 5)

    return render_template(
        "student_dashboard.html",
        routes=routes,
        buses=buses,
        student_name=student_name,
        student_id=student_id,
        preferred_stop=preferred_stop,
        preferred_route_id=preferred_route_id,
        alert_lead_minutes=alert_lead_minutes,
        google_maps_api_key=AppConfig.GOOGLE_MAPS_API_KEY,
        university_location=AppConfig.UNIVERSITY_LOCATION
    )
