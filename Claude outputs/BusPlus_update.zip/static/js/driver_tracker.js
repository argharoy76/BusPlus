/**
 * Khulna University Bus Tracker (BusPlus)
 * Driver app: full-screen map, GPS on automatically, one bus icon with a menu
 *   - "Your bus": only this driver's bus (and its route + trail)
 *   - "All buses": every route and every live bus (with their trails)
 *   - Today's duty: which bus to drive on which route (set daily by the admin)
 */

class DriverApp {
    constructor() {
        const data = window.DRIVER_DATA || {};
        this.driver = data.driver || {};
        this.bus = data.bus || {};
        this.routes = data.routes || [];
        this.allBuses = [];

        this.view = this.readSetting("busplus_driver_view", "mine"); // "mine" | "all"
        this.follow = true;          // keep the own bus in view until the driver pans the map
        this.watchId = null;
        this.lastSent = { t: 0, lat: null, lng: null };
        this.sending = false;
        this.wakeLock = null;
        this.pollTimer = null;
        this.dutyTimer = null;
        this.duty = null;
        this.firstFit = true;

        this.el = {
            icon: document.getElementById("drv-icon"),
            menu: document.getElementById("drv-menu"),
            backdrop: document.getElementById("drv-backdrop"),
            gpsDot: document.getElementById("drv-gps-dot"),
            unseenDot: document.getElementById("drv-unseen-dot"),
            gpsState: document.getElementById("drv-gps-state"),
            gpsRetry: document.getElementById("drv-gps-retry"),
            banner: document.getElementById("drv-banner"),
            logout: document.getElementById("drv-logout"),
            duty: document.getElementById("drv-duty"),
            dutyBadge: document.getElementById("drv-duty-badge"),
            dutyDate: document.getElementById("drv-duty-date"),
            dutyBus: document.getElementById("drv-duty-bus"),
            dutyBusDot: document.getElementById("drv-duty-bus-dot"),
            dutyPlate: document.getElementById("drv-duty-plate"),
            dutyRoute: document.getElementById("drv-duty-route"),
            dutyRouteSwatch: document.getElementById("drv-duty-route-swatch"),
            dutyStops: document.getElementById("drv-duty-stops"),
        };
    }

    readSetting(key, fallback) {
        try { return localStorage.getItem(key) || fallback; } catch (e) { return fallback; }
    }

    writeSetting(key, value) {
        try { localStorage.setItem(key, value); } catch (e) { /* private mode */ }
    }

    async init() {
        const helper = window.googleMapsHelper;
        await helper.initMap("driver-map", {
            center: {
                lat: this.bus.current_latitude || 22.8021,
                lng: this.bus.current_longitude || 89.5340
            },
            zoom: 14
        });

        helper.drawRoutes(this.routes);
        const firstRoute = this.routes[0];
        const dest = firstRoute?.stops?.[firstRoute.stops.length - 1];
        if (dest) helper.updateDestinationMarker(dest.latitude, dest.longitude, dest.stop_name);

        // Panning by hand stops "follow my bus" until "Your bus" is chosen again
        helper.leafletMap?.on("dragstart", () => { this.follow = false; });

        this.bindMenu();
        this.applyView(this.view, { fit: true });

        this.startGps();
        this.loadDuty();
        this.refreshBuses();
        this.pollTimer = setInterval(() => this.refreshBuses(), 3000);
        this.dutyTimer = setInterval(() => this.loadDuty(), 60000);

        document.addEventListener("visibilitychange", () => {
            if (document.visibilityState === "visible") this.requestWakeLock();
        });
    }

    // ------------------------------------------------------------------
    // Menu
    // ------------------------------------------------------------------
    bindMenu() {
        this.el.icon.addEventListener("click", () => this.toggleMenu());
        this.el.backdrop.addEventListener("click", () => this.closeMenu());
        document.addEventListener("keydown", (e) => { if (e.key === "Escape") this.closeMenu(); });

        document.querySelectorAll(".drv-view-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                this.applyView(btn.dataset.view, { fit: true });
                this.closeMenu();
            });
        });

        this.el.gpsRetry.addEventListener("click", () => this.startGps());
        this.el.logout.addEventListener("click", () => this.logout());
    }

    toggleMenu() {
        if (this.el.menu.classList.contains("open")) this.closeMenu();
        else this.openMenu();
    }

    openMenu() {
        this.el.menu.classList.add("open");
        this.el.menu.setAttribute("aria-hidden", "false");
        this.el.backdrop.classList.add("open");
        this.el.icon.classList.add("menu-open");
        this.el.icon.setAttribute("aria-expanded", "true");
        this.markDutySeen();
    }

    closeMenu() {
        this.el.menu.classList.remove("open");
        this.el.menu.setAttribute("aria-hidden", "true");
        this.el.backdrop.classList.remove("open");
        this.el.icon.classList.remove("menu-open");
        this.el.icon.setAttribute("aria-expanded", "false");
    }

    // ------------------------------------------------------------------
    // Your bus / All buses
    // ------------------------------------------------------------------
    applyView(view, { fit = false } = {}) {
        this.view = view === "all" ? "all" : "mine";
        this.writeSetting("busplus_driver_view", this.view);
        if (this.view === "mine") this.follow = true;

        document.querySelectorAll(".drv-view-btn").forEach(btn => {
            const on = btn.dataset.view === this.view;
            btn.classList.toggle("active", on);
            btn.setAttribute("aria-checked", on ? "true" : "false");
        });

        const helper = window.googleMapsHelper;
        helper.showRoutes(this.view === "mine" && this.bus.assigned_route_id ? [this.bus.assigned_route_id] : null);
        this.drawBuses();

        if (!fit) return;
        if (this.view === "mine") {
            if (this.bus.is_active && this.bus.current_latitude) {
                helper.fitToPoints([[this.bus.current_latitude, this.bus.current_longitude]], 40);
            } else {
                helper.fitToPoints(helper.getRoutePoints(this.bus.assigned_route_id ? [this.bus.assigned_route_id] : null), 40);
            }
        } else {
            helper.fitToPoints(helper.getRoutePoints(null), 40);
        }
    }

    drawBuses() {
        const helper = window.googleMapsHelper;
        const myId = this.bus.bus_id;
        let list = this.allBuses.filter(b => b.is_active);
        if (this.view === "mine") list = list.filter(b => b.bus_id === myId);

        helper.updateTrails(list);
        helper.updateActiveBuses(list);

        // Make the driver's own bus stand out
        const mine = helper.markers[myId];
        const el = mine && mine.getElement ? mine.getElement() : null;
        el?.querySelector(".gmap-bus-container")?.classList.add("is-mine");
    }

    async refreshBuses() {
        try {
            const resp = await fetch("/api/buses");
            const data = await resp.json();
            if (!data.success) return;
            this.allBuses = data.buses || [];
            const mine = this.allBuses.find(b => b.bus_id === this.bus.bus_id);
            if (mine) {
                const routeChanged = mine.assigned_route_id !== this.bus.assigned_route_id;
                this.bus = mine;
                if (routeChanged) {
                    this.applyView(this.view, { fit: this.view === "mine" });
                    this.loadDuty();
                    return;
                }
            }
            this.drawBuses();
            if (this.view === "mine" && this.follow && this.bus.is_active && this.bus.current_latitude) {
                if (this.firstFit) {
                    window.googleMapsHelper.fitToPoints([[this.bus.current_latitude, this.bus.current_longitude]], 40);
                    this.firstFit = false;
                } else {
                    window.googleMapsHelper.leafletMap?.panTo([this.bus.current_latitude, this.bus.current_longitude], { animate: true });
                }
            }
        } catch (err) {
            // network blip: try again on the next tick
        }
    }

    // ------------------------------------------------------------------
    // GPS (turns on by itself)
    // ------------------------------------------------------------------
    setGpsState(state, text) {
        this.el.gpsDot.className = `drv-gps-dot ${state}`;
        this.el.gpsState.className = `drv-gps-state ${state}`;
        this.el.gpsState.textContent = text;
        this.el.gpsRetry.hidden = state !== "off";
    }

    showBanner(text) {
        this.el.banner.textContent = text;
        this.el.banner.hidden = !text;
    }

    async startGps() {
        if (!window.isSecureContext) {
            this.setGpsState("off", "GPS needs HTTPS");
            this.showBanner("GPS can't start: phones only share location with sites opened over HTTPS (or on this computer as localhost).");
            return;
        }
        if (!navigator.geolocation) {
            this.setGpsState("off", "No GPS on this device");
            this.showBanner("This device or browser can't share its location.");
            return;
        }

        this.setGpsState("", "Starting GPS…");
        this.showBanner("");

        const started = await this.post("/api/driver/trip/start", {});
        if (!started) return;

        if (this.watchId !== null) navigator.geolocation.clearWatch(this.watchId);
        this.watchId = navigator.geolocation.watchPosition(
            (pos) => this.onPosition(pos),
            (err) => this.onGpsError(err),
            { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 }
        );
        this.requestWakeLock();
    }

    onPosition(pos) {
        const { latitude, longitude, speed, heading } = pos.coords;
        this.setGpsState("on", "GPS on · sharing location");
        this.showBanner("");

        // Send at most every 3 s, or sooner if the bus moved more than ~15 m
        const now = Date.now();
        const moved = this.lastSent.lat === null ? Infinity
            : Math.hypot(latitude - this.lastSent.lat, (longitude - this.lastSent.lng) * Math.cos(latitude * Math.PI / 180)) * 111000;
        if (this.sending || (now - this.lastSent.t < 3000 && moved < 15)) return;

        this.lastSent = { t: now, lat: latitude, lng: longitude };
        this.sending = true;
        this.post("/api/driver/location", {
            latitude,
            longitude,
            // Many phones don't report speed: send null and the server works it out from the movement
            speed_kmh: typeof speed === "number" && !Number.isNaN(speed) ? speed * 3.6 : null,
            // Only send a heading the phone actually knows; otherwise the server works it out
            heading_deg: typeof heading === "number" && !Number.isNaN(heading) ? heading : null
        }).then(data => {
            if (data && data.bus) {
                this.bus = { ...this.bus, ...data.bus };
                const idx = this.allBuses.findIndex(b => b.bus_id === data.bus.bus_id);
                if (idx >= 0) this.allBuses[idx] = { ...this.allBuses[idx], ...data.bus };
                else this.allBuses.push(data.bus);
                this.drawBuses();
            }
        });
    }

    onGpsError(err) {
        if (err.code === 1) {
            this.setGpsState("off", "Location blocked");
            this.showBanner("Location is blocked for BusPlus. Allow location in your browser settings, then tap the bus icon → Turn on.");
            if (this.watchId !== null) navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        } else if (err.code === 3) {
            this.setGpsState("", "Waiting for GPS signal…");
        } else {
            this.setGpsState("off", "GPS unavailable");
            this.showBanner("Can't get a GPS position right now. Move to an open area and tap the bus icon → Turn on.");
        }
    }

    async requestWakeLock() {
        // Keeps the screen (and GPS) awake while driving, where the browser supports it
        try {
            if ("wakeLock" in navigator && document.visibilityState === "visible" && !this.wakeLock) {
                this.wakeLock = await navigator.wakeLock.request("screen");
                this.wakeLock.addEventListener("release", () => { this.wakeLock = null; });
            }
        } catch (e) { /* not allowed right now */ }
    }

    // ------------------------------------------------------------------
    // Today's duty (notification)
    // ------------------------------------------------------------------
    async loadDuty() {
        try {
            const resp = await fetch("/api/driver/assignment");
            if (resp.status === 401) return this.sessionLost();
            const data = await resp.json();
            if (!data.success) return;
            this.duty = data.assignment;
            this.renderDuty();
        } catch (e) { /* try again later */ }
    }

    renderDuty() {
        const d = this.duty;
        if (!d) return;
        this.el.dutyDate.textContent = d.date_label || "";
        this.el.dutyBus.textContent = d.bus_number ? `${d.bus_number} · ${d.bus_name || ""}` : "No bus assigned";
        this.el.dutyPlate.textContent = d.license_plate || "";
        this.el.dutyBusDot.style.setProperty("--bus-color", d.bus_color || "#94a3b8");
        this.el.dutyRoute.textContent = d.route_name || "No route";
        this.el.dutyRouteSwatch.style.setProperty("--route-color", d.route_color || "#94a3b8");
        this.el.dutyStops.textContent = d.from_stop
            ? `${d.from_stop}${d.from_time ? ` (${d.from_time})` : ""} → ${d.to_stop}`
            : "";
        this.el.dutyBadge.hidden = !d.changed_today;
        this.el.duty.classList.toggle("is-new", !!d.unseen);
        this.el.unseenDot.hidden = !d.unseen;
        if (d.unseen && this.el.menu.classList.contains("open")) this.markDutySeen();
    }

    async markDutySeen() {
        if (!this.duty || !this.duty.unseen) return;
        this.el.unseenDot.hidden = true;
        await this.post("/api/driver/assignment/seen", {});
        this.duty.unseen = false;
    }

    // ------------------------------------------------------------------
    // Session
    // ------------------------------------------------------------------
    async post(url, body) {
        try {
            const resp = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body || {})
            });
            if (resp.status === 401 || resp.status === 409) {
                this.sessionLost();
                return null;
            }
            const data = await resp.json().catch(() => ({}));
            if (resp.status === 404 && data.message) {
                this.setGpsState("off", "No bus assigned");
                this.showBanner(data.message);
                return null;
            }
            return data;
        } catch (e) {
            return null;   // offline for a moment; the next GPS fix will retry
        } finally {
            if (url === "/api/driver/location") this.sending = false;
        }
    }

    sessionLost() {
        if (this.watchId !== null) navigator.geolocation.clearWatch(this.watchId);
        window.location.href = "/driver/login";
    }

    async logout() {
        if (this.watchId !== null) navigator.geolocation.clearWatch(this.watchId);
        this.watchId = null;
        clearInterval(this.pollTimer);
        clearInterval(this.dutyTimer);
        try { await this.wakeLock?.release(); } catch (e) {}
        try {
            await fetch("/api/auth/logout", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: "{}"
            });
        } catch (e) {}
        window.location.href = "/";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    window.driverApp = new DriverApp();
    window.driverApp.init();
});
